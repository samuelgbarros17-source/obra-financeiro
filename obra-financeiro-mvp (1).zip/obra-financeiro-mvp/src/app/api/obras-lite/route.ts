import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET() {
  const obras = await prisma.obra.findMany({ select: { id: true, nome: true }, orderBy: { createdAt: "desc" } });
  return NextResponse.json({ obras });
}
