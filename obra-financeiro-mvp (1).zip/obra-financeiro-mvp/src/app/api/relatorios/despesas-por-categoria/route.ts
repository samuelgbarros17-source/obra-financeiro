import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const obraId = url.searchParams.get("obraId") || undefined;

  const cats = await prisma.categoria.findMany({ orderBy: { nome: "asc" } });
  const rows = await Promise.all(cats.map(async (c) => {
    const agg = await prisma.lancamento.aggregate({
      where: { categoriaId: c.id, tipo: "DESPESA", ...(obraId ? { obraId } : {}) },
      _sum: { valor: true },
    });
    return { categoria: c.nome, total: Number(agg._sum.valor ?? 0) };
  }));

  return NextResponse.json({ rows });
}
