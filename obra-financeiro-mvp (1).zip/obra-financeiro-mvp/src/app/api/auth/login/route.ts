import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const password = String(body?.password ?? "");
  const ok = password && password === process.env.APP_PASSWORD;

  if (!ok) {
    return NextResponse.json({ ok: false, message: "Senha inválida" }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true });
  res.cookies.set("ofm_auth", "1", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
  });
  return res;
}
