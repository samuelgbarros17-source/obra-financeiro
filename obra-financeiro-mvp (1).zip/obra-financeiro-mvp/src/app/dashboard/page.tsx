import { Shell } from "@/components/Shell";
import { Card, H1, Muted } from "@/components/ui";
import { prisma } from "@/lib/db";
import { brl } from "@/lib/format";

export default async function Dashboard() {
  const obras = await prisma.obra.findMany({ orderBy: { createdAt: "desc" } });

  // Totais globais
  const [recAgg, despAgg] = await Promise.all([
    prisma.lancamento.aggregate({ where: { tipo: "RECEITA" }, _sum: { valor: true } }),
    prisma.lancamento.aggregate({ where: { tipo: "DESPESA" }, _sum: { valor: true } }),
  ]);

  const receitas = Number(recAgg._sum.valor ?? 0);
  const despesas = Number(despAgg._sum.valor ?? 0);
  const saldo = receitas - despesas;

  const rows = await Promise.all(obras.map(async (obra) => {
    const [prevAgg, rec, desp] = await Promise.all([
      prisma.orcamentoCategoria.aggregate({ where: { obraId: obra.id }, _sum: { valorPrevisto: true } }),
      prisma.lancamento.aggregate({ where: { obraId: obra.id, tipo: "RECEITA" }, _sum: { valor: true } }),
      prisma.lancamento.aggregate({ where: { obraId: obra.id, tipo: "DESPESA" }, _sum: { valor: true } }),
    ]);
    const previsto = Number(prevAgg._sum.valorPrevisto ?? 0);
    const r = Number(rec._sum.valor ?? 0);
    const d = Number(desp._sum.valor ?? 0);
    const s = r - d;
    const pct = previsto > 0 ? (d / previsto) * 100 : 0;
    return { obra, previsto, receitas: r, despesas: d, saldo: s, pct };
  }));

  return (
    <Shell>
      <div className="flex items-baseline justify-between">
        <H1>Dashboard</H1>
        <Muted>Visão geral (sem filtro de período no MVP inicial).</Muted>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-3">
        <Card>
          <div className="text-sm text-zinc-600">Receitas</div>
          <div className="text-2xl font-semibold">{brl(receitas)}</div>
        </Card>
        <Card>
          <div className="text-sm text-zinc-600">Despesas</div>
          <div className="text-2xl font-semibold">{brl(despesas)}</div>
        </Card>
        <Card>
          <div className="text-sm text-zinc-600">Saldo</div>
          <div className="text-2xl font-semibold">{brl(saldo)}</div>
        </Card>
      </div>

      <div className="mt-6 card p-4 overflow-auto">
        <div className="font-semibold mb-2">Obras</div>
        <table className="min-w-[900px] w-full text-sm">
          <thead className="text-left text-zinc-600">
            <tr className="border-b">
              <th className="py-2">Nome</th>
              <th>Previsto</th>
              <th>Realizado (Despesas)</th>
              <th>%</th>
              <th>Saldo</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.obra.id} className="border-b last:border-b-0">
                <td className="py-2">
                  <a className="font-medium" href={`/obras/${r.obra.id}`}>{r.obra.nome}</a>
                  <div className="text-xs text-zinc-500">{r.obra.cliente ?? ""}</div>
                </td>
                <td>{brl(r.previsto)}</td>
                <td>{brl(r.despesas)}</td>
                <td>{r.pct.toFixed(1)}%</td>
                <td>{brl(r.saldo)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}
