import { Shell } from "@/components/Shell";
import { Button, Card, H1, Input, Label, Select } from "@/components/ui";
import { prisma } from "@/lib/db";
import { brl, isoDate } from "@/lib/format";
import { calcStatus } from "@/lib/status";
import { revalidatePath } from "next/cache";
import { z } from "zod";

async function updatePrevisto(formData: FormData) {
  "use server";
  const obraId = String(formData.get("obraId"));
  const categoriaId = String(formData.get("categoriaId"));
  const valorPrevisto = Number(String(formData.get("valorPrevisto") ?? "0").replace(",", "."));
  if (!obraId || !categoriaId) throw new Error("Dados inválidos");
  await prisma.orcamentoCategoria.update({
    where: { obraId_categoriaId: { obraId, categoriaId } },
    data: { valorPrevisto },
  });
  revalidatePath(`/obras/${obraId}`);
}

const lancSchema = z.object({
  obraId: z.string().min(1),
  categoriaId: z.string().min(1),
  tipo: z.enum(["RECEITA", "DESPESA"]),
  descricao: z.string().min(2),
  valor: z.coerce.number().positive(),
  dataCompetencia: z.string().min(10),
  dataVencimento: z.string().optional(),
  dataPagamento: z.string().optional(),
});

async function createLancamento(formData: FormData) {
  "use server";
  const raw = Object.fromEntries(formData.entries());
  const parsed = lancSchema.safeParse(raw);
  if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? "Dados inválidos");

  const dcomp = new Date(parsed.data.dataCompetencia);
  const dv = parsed.data.dataVencimento ? new Date(parsed.data.dataVencimento) : null;
  const dp = parsed.data.dataPagamento ? new Date(parsed.data.dataPagamento) : null;
  const status = calcStatus({ dataVencimento: dv, dataPagamento: dp });

  await prisma.lancamento.create({
    data: {
      obraId: parsed.data.obraId,
      categoriaId: parsed.data.categoriaId,
      tipo: parsed.data.tipo,
      descricao: parsed.data.descricao,
      valor: parsed.data.valor,
      dataCompetencia: dcomp,
      dataVencimento: dv,
      dataPagamento: dp,
      status,
    }
  });

  revalidatePath(`/obras/${parsed.data.obraId}`);
}

export default async function ObraDetail({ params }: { params: { id: string } }) {
  const obra = await prisma.obra.findUnique({ where: { id: params.id } });
  if (!obra) return <div>Obra não encontrada.</div>;

  const [categorias, orcamentos, lancs] = await Promise.all([
    prisma.categoria.findMany({ orderBy: { nome: "asc" } }),
    prisma.orcamentoCategoria.findMany({
      where: { obraId: obra.id },
      include: { categoria: true },
      orderBy: { categoria: { nome: "asc" } },
    }),
    prisma.lancamento.findMany({
      where: { obraId: obra.id },
      include: { categoria: true },
      orderBy: { dataCompetencia: "desc" },
      take: 50,
    }),
  ]);

  const despesas = lancs.filter(l => l.tipo === "DESPESA").reduce((a, b) => a + Number(b.valor), 0);
  const receitas = lancs.filter(l => l.tipo === "RECEITA").reduce((a, b) => a + Number(b.valor), 0);
  const saldo = receitas - despesas;
  const previstoTotal = orcamentos.reduce((a, o) => a + Number(o.valorPrevisto), 0);
  const pct = previstoTotal > 0 ? (despesas / previstoTotal) * 100 : 0;

  // realizado por categoria (despesa)
  const realPorCat = new Map<string, number>();
  for (const l of lancs) {
    if (l.tipo !== "DESPESA") continue;
    realPorCat.set(l.categoriaId, (realPorCat.get(l.categoriaId) ?? 0) + Number(l.valor));
  }

  return (
    <Shell>
      <div className="flex items-baseline justify-between gap-3 flex-wrap">
        <div>
          <H1>{obra.nome}</H1>
          <div className="text-sm text-zinc-600">{obra.cliente ?? ""} {obra.endereco ? "• " + obra.endereco : ""}</div>
        </div>
        <a href="/obras"><Button variant="secondary">Voltar</Button></a>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-4">
        <Card><div className="text-sm text-zinc-600">Receitas</div><div className="text-xl font-semibold">{brl(receitas)}</div></Card>
        <Card><div className="text-sm text-zinc-600">Despesas</div><div className="text-xl font-semibold">{brl(despesas)}</div></Card>
        <Card><div className="text-sm text-zinc-600">Saldo</div><div className="text-xl font-semibold">{brl(saldo)}</div></Card>
        <Card><div className="text-sm text-zinc-600">% Realizado</div><div className="text-xl font-semibold">{pct.toFixed(1)}%</div></Card>
      </div>

      <div className="mt-6 grid gap-3 lg:grid-cols-2">
        <Card className="overflow-auto">
          <div className="font-semibold mb-2">Orçamento por categoria</div>
          <table className="min-w-[720px] w-full text-sm">
            <thead className="text-left text-zinc-600">
              <tr className="border-b">
                <th className="py-2">Categoria</th>
                <th>Previsto</th>
                <th>Realizado (desp.)</th>
                <th>Diferença</th>
                <th>%</th>
                <th>Editar</th>
              </tr>
            </thead>
            <tbody>
              {orcamentos.map((o) => {
                const real = realPorCat.get(o.categoriaId) ?? 0;
                const prev = Number(o.valorPrevisto);
                const diff = prev - real;
                const p = prev > 0 ? (real / prev) * 100 : 0;
                return (
                  <tr key={o.id} className="border-b last:border-b-0">
                    <td className="py-2">{o.categoria.nome}</td>
                    <td>{brl(prev)}</td>
                    <td>{brl(real)}</td>
                    <td>{brl(diff)}</td>
                    <td>{p.toFixed(1)}%</td>
                    <td>
                      <form action={updatePrevisto} className="flex items-center gap-2">
                        <input type="hidden" name="obraId" value={obra.id} />
                        <input type="hidden" name="categoriaId" value={o.categoriaId} />
                        <Input name="valorPrevisto" defaultValue={String(prev)} className="w-28" />
                        <Button type="submit" variant="secondary">Salvar</Button>
                      </form>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>

        <Card>
          <div className="font-semibold mb-2">Novo lançamento</div>
          <form action={createLancamento} className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input type="hidden" name="obraId" value={obra.id} />
            <div className="md:col-span-2">
              <Label>Descrição</Label>
              <Input name="descricao" placeholder="Ex: Compra de cimento" required />
            </div>
            <div>
              <Label>Tipo</Label>
              <Select name="tipo" defaultValue="DESPESA">
                <option value="DESPESA">Despesa</option>
                <option value="RECEITA">Receita</option>
              </Select>
            </div>
            <div>
              <Label>Categoria</Label>
              <Select name="categoriaId" required>
                {categorias.map(c => <option key={c.id} value={c.id}>{c.nome}</option>)}
              </Select>
            </div>
            <div>
              <Label>Valor</Label>
              <Input name="valor" type="number" step="0.01" min="0" required />
            </div>
            <div>
              <Label>Data competência</Label>
              <Input name="dataCompetencia" type="date" defaultValue={isoDate(new Date())} required />
            </div>
            <div>
              <Label>Vencimento (opcional)</Label>
              <Input name="dataVencimento" type="date" />
            </div>
            <div>
              <Label>Pagamento (opcional)</Label>
              <Input name="dataPagamento" type="date" />
            </div>
            <div className="md:col-span-2">
              <Button type="submit">Salvar lançamento</Button>
            </div>
          </form>
        </Card>
      </div>

      <div className="mt-6 card p-4 overflow-auto">
        <div className="font-semibold mb-2">Lançamentos (últimos 50)</div>
        <table className="min-w-[980px] w-full text-sm">
          <thead className="text-left text-zinc-600">
            <tr className="border-b">
              <th className="py-2">Data</th>
              <th>Tipo</th>
              <th>Categoria</th>
              <th>Descrição</th>
              <th>Valor</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {lancs.map((l) => (
              <tr key={l.id} className="border-b last:border-b-0">
                <td className="py-2">{isoDate(l.dataCompetencia)}</td>
                <td className="text-xs">{l.tipo}</td>
                <td>{l.categoria.nome}</td>
                <td>{l.descricao}</td>
                <td>{brl(Number(l.valor))}</td>
                <td className="text-xs">{l.status}</td>
              </tr>
            ))}
            {lancs.length === 0 ? (
              <tr><td className="py-3 text-zinc-600" colSpan={6}>Sem lançamentos.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}
