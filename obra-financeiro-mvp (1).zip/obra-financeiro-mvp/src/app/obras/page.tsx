import { Shell } from "@/components/Shell";
import { Button, Card, H1, Input, Label } from "@/components/ui";
import { prisma } from "@/lib/db";
import { revalidatePath } from "next/cache";
import { z } from "zod";

const schema = z.object({
  nome: z.string().min(2, "Informe o nome"),
  cliente: z.string().optional(),
  endereco: z.string().optional(),
});

async function createObra(formData: FormData) {
  "use server";
  const raw = {
    nome: String(formData.get("nome") ?? ""),
    cliente: String(formData.get("cliente") ?? "") || undefined,
    endereco: String(formData.get("endereco") ?? "") || undefined,
  };
  const parsed = schema.safeParse(raw);
  if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? "Dados inválidos");

  const categorias = await prisma.categoria.findMany();
  const obra = await prisma.obra.create({ data: { ...parsed.data } });

  // criar orçamento p/ todas as categorias
  await prisma.orcamentoCategoria.createMany({
    data: categorias.map((c) => ({ obraId: obra.id, categoriaId: c.id, valorPrevisto: 0 })),
  });

  revalidatePath("/obras");
}

export default async function ObrasPage() {
  const obras = await prisma.obra.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <Shell>
      <div className="flex items-center justify-between">
        <H1>Obras</H1>
        <a href="/obras/novo"><Button>Nova obra</Button></a>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <Card>
          <div className="font-semibold">Criar rápido</div>
          <form action={createObra} className="mt-3 space-y-3">
            <div>
              <Label>Nome</Label>
              <Input name="nome" placeholder="Ex: Obra Residencial X" required />
            </div>
            <div>
              <Label>Cliente (opcional)</Label>
              <Input name="cliente" placeholder="Ex: João" />
            </div>
            <div>
              <Label>Endereço (opcional)</Label>
              <Input name="endereco" placeholder="Rua, nº" />
            </div>
            <Button type="submit">Criar</Button>
          </form>
        </Card>

        <Card className="overflow-auto">
          <div className="font-semibold mb-2">Lista</div>
          <table className="w-full text-sm">
            <thead className="text-left text-zinc-600">
              <tr className="border-b">
                <th className="py-2">Obra</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {obras.map((o) => (
                <tr key={o.id} className="border-b last:border-b-0">
                  <td className="py-2">
                    <a href={`/obras/${o.id}`} className="font-medium">{o.nome}</a>
                    <div className="text-xs text-zinc-500">{o.cliente ?? ""}</div>
                  </td>
                  <td className="text-xs">{o.status}</td>
                </tr>
              ))}
              {obras.length === 0 ? (
                <tr><td className="py-3 text-zinc-600" colSpan={2}>Nenhuma obra ainda.</td></tr>
              ) : null}
            </tbody>
          </table>
        </Card>
      </div>
    </Shell>
  );
}
