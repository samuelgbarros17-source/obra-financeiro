import { Shell } from "@/components/Shell";
import { Button, Card, H1, Input, Label } from "@/components/ui";
import { prisma } from "@/lib/db";
import { revalidatePath } from "next/cache";
import { z } from "zod";

const schema = z.object({ nome: z.string().min(2, "Informe o nome") });

async function createCategoria(formData: FormData) {
  "use server";
  const raw = { nome: String(formData.get("nome") ?? "").trim() };
  const parsed = schema.safeParse(raw);
  if (!parsed.success) throw new Error(parsed.error.issues[0]?.message ?? "Dados inválidos");

  const categoria = await prisma.categoria.create({ data: { nome: parsed.data.nome } });
  const obras = await prisma.obra.findMany({ select: { id: true } });

  await prisma.orcamentoCategoria.createMany({
    data: obras.map(o => ({ obraId: o.id, categoriaId: categoria.id, valorPrevisto: 0 })),
  });

  revalidatePath("/categorias");
}

export default async function CategoriasPage() {
  const categorias = await prisma.categoria.findMany({ orderBy: { nome: "asc" } });

  return (
    <Shell>
      <div className="flex items-center justify-between">
        <H1>Categorias</H1>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <Card>
          <div className="font-semibold">Nova categoria</div>
          <form action={createCategoria} className="mt-3 space-y-3">
            <div>
              <Label>Nome</Label>
              <Input name="nome" placeholder="Ex: Fundação" required />
              <div className="text-xs text-zinc-500 mt-1">
                No MVP, categorias são gerais e valem para todas as obras.
              </div>
            </div>
            <Button type="submit">Criar</Button>
          </form>
        </Card>

        <Card className="overflow-auto">
          <div className="font-semibold mb-2">Lista</div>
          <ul className="text-sm space-y-2">
            {categorias.map(c => (
              <li key={c.id} className="flex items-center justify-between border-b last:border-b-0 py-2">
                <span>{c.nome}</span>
                <span className="text-xs text-zinc-500">—</span>
              </li>
            ))}
            {categorias.length === 0 ? <li className="text-zinc-600">Nenhuma categoria.</li> : null}
          </ul>
        </Card>
      </div>
    </Shell>
  );
}
