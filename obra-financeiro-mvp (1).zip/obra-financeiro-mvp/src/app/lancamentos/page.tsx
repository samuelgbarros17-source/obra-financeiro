import { Shell } from "@/components/Shell";
import { Card, H1, Muted } from "@/components/ui";
import { prisma } from "@/lib/db";
import { brl, isoDate } from "@/lib/format";

export default async function LancamentosPage() {
  const lancs = await prisma.lancamento.findMany({
    include: { obra: true, categoria: true },
    orderBy: { dataCompetencia: "desc" },
    take: 200,
  });

  return (
    <Shell>
      <div className="flex items-baseline justify-between">
        <H1>Lançamentos</H1>
        <Muted>Lista global (top 200). No detalhe da obra você cadastra novos.</Muted>
      </div>

      <div className="mt-4 card p-4 overflow-auto">
        <table className="min-w-[1100px] w-full text-sm">
          <thead className="text-left text-zinc-600">
            <tr className="border-b">
              <th className="py-2">Data</th>
              <th>Obra</th>
              <th>Tipo</th>
              <th>Categoria</th>
              <th>Descrição</th>
              <th>Valor</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {lancs.map(l => (
              <tr key={l.id} className="border-b last:border-b-0">
                <td className="py-2">{isoDate(l.dataCompetencia)}</td>
                <td><a className="font-medium" href={`/obras/${l.obraId}`}>{l.obra.nome}</a></td>
                <td className="text-xs">{l.tipo}</td>
                <td>{l.categoria.nome}</td>
                <td>{l.descricao}</td>
                <td>{brl(Number(l.valor))}</td>
                <td className="text-xs">{l.status}</td>
              </tr>
            ))}
            {lancs.length === 0 ? (
              <tr><td className="py-3 text-zinc-600" colSpan={7}>Sem lançamentos.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}
