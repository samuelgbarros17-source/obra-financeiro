"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "./ui";

const items = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/obras", label: "Obras" },
  { href: "/categorias", label: "Categorias" },
  { href: "/lancamentos", label: "Lançamentos" },
  { href: "/relatorios", label: "Relatórios" },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
  }

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-[260px_1fr]">
      <aside className="border-r border-zinc-200 bg-white p-4">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Obra Financeiro</div>
          <Button variant="secondary" onClick={logout}>Sair</Button>
        </div>
        <nav className="mt-4 space-y-1">
          {items.map((it) => {
            const active = pathname?.startsWith(it.href);
            return (
              <Link
                key={it.href}
                href={it.href}
                className={`block rounded-xl px-3 py-2 text-sm border ${
                  active ? "bg-zinc-900 text-white border-zinc-900" : "border-transparent hover:bg-zinc-50"
                }`}
              >
                {it.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-6 text-xs text-zinc-500">
          MVP (categoria). Troca pra Postgres depois.
        </div>
      </aside>
      <main className="p-4 md:p-8">{children}</main>
    </div>
  );
}
