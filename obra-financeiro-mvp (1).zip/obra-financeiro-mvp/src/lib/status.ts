export function calcStatus(args: { dataVencimento?: Date | null; dataPagamento?: Date | null }) {
  const { dataVencimento, dataPagamento } = args;
  if (dataPagamento) return "PAGO" as const;
  if (dataVencimento) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const dv = new Date(dataVencimento);
    dv.setHours(0,0,0,0);
    if (dv < today) return "ATRASADO" as const;
  }
  return "ABERTO" as const;
}
